#ifndef DYNN_RENDERER_H
#define DYNN_RENDERER_H

#include <vector>
#include <mutiny/mutiny.h>
#include <GL/glew.h>

//#include "Vector3.h"
//#include "Color.h"
#include "dynnParticles.h"
namespace mutiny
{

	namespace engine
	{

	class GameObject;
	class Material;

		class dynnRenderer : public Component
		{
			friend class mutiny::engine::GameObject;
		public:
			
		private:
			std::vector<dynnParticles> allParticles;
			GLuint vertBuff;
			GLuint uvBuff;
			ref<Material> material;
			
		virtual void render();
		virtual void awake();
		};
	
	}
	
}
#endif