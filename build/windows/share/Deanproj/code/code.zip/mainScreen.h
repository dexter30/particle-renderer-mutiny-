#ifndef MAINSCREEN_H
#define MAINSCREEN_H

#include <mutiny/mutiny.h>
#include "dynnRenderer.h"
#include <memory>

using namespace mutiny::engine;

class mainScreen : public Behaviour
{
public:
  static ref<GameObject> create();
  virtual void onAwake();
  virtual void onUpdate();
  virtual void onGui();

private:
  ref<GameObject> cameraGo;
  ref<GameObject> cube1Go;
  
  }
#endif