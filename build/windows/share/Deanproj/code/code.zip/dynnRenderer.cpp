#include "dynnRenderer.h"

namespace mutiny
{

	namespace engine
	{
		void dynnRenderer::awake()
		{
			glGenBuffers(1, &vertBuff);
			glGenBuffers(1, &uvBuff);
			
			dynnParticles part1;
			part1.pos = Vector3(-0.5, -0.5f, 0);
			//part1.vel = Vector3(-5.0, 0.1f, 0);
			                                    
			dynnParticles part2;                
			part2.pos = Vector3(0.5, -0.5f, 0) ;
			//part2.vel = Vector3(-5.0, 0.1f, 0);
			                                    
			dynnParticles part3;                
			part3.pos = Vector3(-0.5, 0.5f, 0) ;
			//part3.vel = Vector3(-5.0, 0.1f, 0);
			                                    
			dynnParticles part4;                
			part4.pos = Vector3(0.5, 0.5f, 0) ;
			//part4.vel = Vector3(-5.0, 0.1f, 0);
			                                    
			dynnParticles part5;                
			part5.pos = Vector3(-0.5, 0.5f, 0.0) ;
			                                    
			dynnParticles part6;                
			part6.pos = Vector3(0.5, -0.5f, 0.0) ;
			
			allParticles.push_back(part3);
			allParticles.push_back(part2);
			allParticles.push_back(part1);
			
			allParticles.push_back(part6);
			allParticles.push_back(part5);
			allParticles.push_back(part4);
			
			std::vector<float> valuesToGPU; //vertex coords to be uploaded to buffers
			allParticles[0].vel = Vector3(-0.6, 0.2f, 0);
			allParticles[1].vel = Vector3(0.6, -0.2f, 0);
			allParticles[2].vel = Vector3(-0.2, 0.6f, 0);
			allParticles[3].vel = Vector3(0.2, -0.6f, 0);
			allParticles[4].vel = Vector3(0.6, 0.2f, 0);
			allParticles[5].vel = Vector3(-0.6, -0.2f, 0);
			
			allParticles[0].lifetime = Random::range(1.0f,10.0f);
			allParticles[1].lifetime = Random::range(1.0f,10.0f);
			allParticles[2].lifetime = Random::range(1.0f,10.0f);
			allParticles[3].lifetime = Random::range(1.0f,10.0f);
			allParticles[4].lifetime = Random::range(1.0f,10.0f);
			allParticles[5].lifetime = Random::range(1.0f,10.0f);
			
			for(int i = 0; i < allParticles.size(); i++)
			{
				valuesToGPU.push_back(allParticles.at(i).pos.x);
				valuesToGPU.push_back(allParticles.at(i).pos.y);
				valuesToGPU.push_back(allParticles.at(i).pos.z);
			}
			
			glBindBuffer(GL_ARRAY_BUFFER, vertBuff);
			glBufferData(GL_ARRAY_BUFFER, valuesToGPU.size() * sizeof(valuesToGPU[0]), &valuesToGPU[0], GL_STATIC_DRAW);
 			
			valuesToGPU.clear();
			
			std::vector<Vector2> uv;

			uv.push_back(Vector2(0, 1));
			uv.push_back(Vector2(0, 0));
			uv.push_back(Vector2(1, 0));
			uv.push_back(Vector2(1, 0));
			uv.push_back(Vector2(1, 1));
			uv.push_back(Vector2(0, 1));
  
			for(int i = 0; i < uv.size(); i++)
			{
				valuesToGPU.push_back(uv.at(i).x);
				valuesToGPU.push_back(uv.at(i).y);
			}
			glBindBuffer(GL_ARRAY_BUFFER, uvBuff);
			glBufferData(GL_ARRAY_BUFFER, valuesToGPU.size() * sizeof(valuesToGPU[0]), &valuesToGPU[0], GL_STATIC_DRAW);
			
			
			
  
			
		}
		
		void dynnRenderer::render()
		{
			ref<Shader> shader;
			ref<Transform> transform = getGameObject()->getTransform();
			material = Resources::load<Material>("shaders/particle");
			shader = material->getShader();
			glUseProgram(shader->programId->getGLuint());
			if(material.expired())
			{
				std::cout<<"somethings fucked m8";
			}
			
			Vector3 axisMod;
			Matrix4x4 viewMat = Matrix4x4::getIdentity();
			axisMod = Camera::getCurrent()->getGameObject()->getTransform()->getRotation();
			axisMod.x *= -1;
			axisMod.y *= -1;
			viewMat = viewMat.rotate(axisMod);
			axisMod = Camera::getCurrent()->getGameObject()->getTransform()->getPosition();
			axisMod.x *= -1;
			axisMod.y *= -1;
			viewMat = viewMat.translate(axisMod);
			
			
			material->setMatrix("in_Projection", Camera::getCurrent()->getProjectionMatrix());
			material->setMatrix("in_View", viewMat);
			
			GLint positionAttribId = glGetAttribLocation(shader->programId->getGLuint(), "in_Position");
			
			glBindBuffer(GL_ARRAY_BUFFER, vertBuff);
			glVertexAttribPointer(positionAttribId, 3, GL_FLOAT, GL_FALSE, 0, 0);
			glEnableVertexAttribArray(positionAttribId);
			
			GLint uvAttribId = glGetAttribLocation(shader->programId->getGLuint(), "in_Uv");
			
			glBindBuffer(GL_ARRAY_BUFFER, uvBuff);
			glVertexAttribPointer(uvAttribId, 2, GL_FLOAT, GL_FALSE, 0, 0);
			glEnableVertexAttribArray(uvAttribId);
			
			GLuint uniformId = glGetUniformLocation(shader->programId->getGLuint(),"in_Projection");
			glUniformMatrix4fv(uniformId, 1, GL_FALSE, Camera::getCurrent()->getProjectionMatrix().getValue());
			
			GLuint uniformId2 = glGetUniformLocation(shader->programId->getGLuint(),"in_View");
			glUniformMatrix4fv(uniformId2, 1, GL_FALSE, viewMat.getValue());
			
			
				
			glDisable(GL_DEPTH_TEST);
						
			
			//glFrontFace(GL_CW);
			for(size_t i = 0; i < allParticles.size(); i++)
			{
				
				//std::cout<<i<<": "<<allParticles.at(i).pos.x<<" "<<allParticles.at(i).pos.y<<" "<<allParticles.at(i).pos.z<<"\n";
				//std::cout<<transform->getPosition().x<<" "<<transform->getPosition().y<<" "<<transform->getPosition().z;
				Matrix4x4 modelMat = Matrix4x4::getIdentity();
				axisMod = allParticles.at(i).pos;
				axisMod.z *= -1;
				modelMat = modelMat.translate(axisMod);
				//modelMat = modelMat.rotate(Vector3(0, 0, 180.0f));
				
				material->setMatrix("in_Model", modelMat);
				
				
				//try to deconstruct setpass and make your own replacement.
				
				//material->setPass(0, material);
				
				
				
				GLuint uniformId3 = glGetUniformLocation(shader->programId->getGLuint(),"in_Model");
				glUniformMatrix4fv(uniformId3, 1, GL_FALSE, modelMat.getValue());

				glDrawArrays(GL_TRIANGLES, 0, 6);
				
				if (allParticles.at(i).lifetime <= 0)
				{
					allParticles.at(i).pos = transform->getPosition();
					allParticles.at(i).lifetime = Random::range(1.0f,10.0f) ;
				}
				allParticles.at(i).pos = allParticles.at(i).pos + (allParticles.at(i).vel * Time::getDeltaTime());
				allParticles.at(i).lifetime -= Time::getDeltaTime();
				
				
				
			}
			if(Input::getKey(KeyCode::LEFT) == true)
			{
				allParticles.erase(allParticles.begin());
			}
			if(Input::getKey(KeyCode::RIGHT) == true)
			{
				dynnParticles newParticle;                
				newParticle.pos = transform->getPosition();
				newParticle.vel = Vector3(Random::range(-10.0f,10.0f), Random::range(-10.0f,10.0f),Random::range(-10.0f,10.0f));
				allParticles.push_back(newParticle);
			}
			
			
			
			 glEnable(GL_DEPTH_TEST);
			glDisableVertexAttribArray(positionAttribId);
			
			glDisableVertexAttribArray(uvAttribId);
			
		}

	}

}