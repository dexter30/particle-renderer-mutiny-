#include "mainScreen.h"

#include <iostream>
;
using namespace mutiny::engine;

ref<GameObject> mainScreen::create()
{
  Debug::log("onAwake()");
  ref<GameObject> mainGo = GameObject::create("mainScene");
  mainGo->addComponent<mainScreen>();

  return mainGo;
}

void mainScreen::onAwake()
{
	cameraGo = GameObject::create("MainCamera");
  ref<Camera> camera = cameraGo->addComponent<Camera>();
  cameraGo->getTransform()->setPosition(Vector3(0, 0, -10));

  cube1Go = GameObject::createPrimitive(PrimitiveType::CUBE);
  cube1Go->getTransform()->setPosition(Vector3(-2, -2, 5));
  cube1Go->setName("cube1Go");
  
  cube1Go->addComponent<dynnRenderer>();

}

void mainScreen::onUpdate()
{
	
}

void mainScreen::onGui()
{
	
}